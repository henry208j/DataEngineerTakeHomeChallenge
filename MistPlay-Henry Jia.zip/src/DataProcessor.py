import pandas as pd
from util import HelperFunctions


if __name__ == '__main__':
    # load json file from data folder into pandas dataframe
    df = pd.read_json("../data/data.json", lines="True")

    # remove duplicates over the columns "id" and "created_at"
    df = df.drop_duplicates(['id', 'created_at'])

    # create column "sub_group_rank" with the rank of each user's user_score within each age group
    df["sub_group_rank"] = df.groupby("age_group")["user_score"].rank('dense')

    """
    process the column widget_list
    """
    # flatten the list in column "widget_list"
    df = df.explode("widget_list")
    # handle the missing values
    df["widget_list"] = df["widget_list"].fillna("")
    # create columns "widget_name" based on the value from "widget_list", handle the empty values will ""
    df["widget_name"] = df["widget_list"].apply(lambda x: x['name'] if x != "" else "")
    # create columns "widget_amount" based on the value from "widget_list", handle the empty values will -1
    df["widget_amount"] = df["widget_list"].apply(lambda x: x['amount'] if x != "" else -1)
    # remove the column "widget_list"
    df.drop(["widget_list"], axis=1, inplace=True)

    """
    anonymize the column "email" 
        1. create a hash map for "email" with a hash function 
        2. create the column "email_anon" with the hash values
    The email can be decrypted with the function "emailDecrypter"
    """
    # create a hash map
    hashmap_email = {emails: i for i, emails in enumerate(df["email"].unique())}
    # create the column "email_anon", add 1 into the original value is for security
    # we can use more complex function in reality in case data breach happens
    df["email_anon"] = df["email"].apply(lambda x: hashmap_email[x]+1)

    # decrypt the column "email_anon" with the hashmap
    email_anon_value = 0
    print(HelperFunctions.email_decrypter(hashmap_email, email_anon_value))

    """
    create a new table that is an inverted index that gives which ids are located in each country in column "location"
    """
    # create a dictionary with location as key and the list of unique ids as value
    dict_country = df[["id", "location"]].drop_duplicates().groupby('location')['id'].apply(list).to_dict()
    # create the new dataframe using the dictionary above
    df_country = pd.DataFrame.from_dict(dict_country, orient='index').transpose()

    """
    write the processed tables/data into separate parquet file(s).
    """
    df.to_parquet('../output/data.parquet')
    df_country.to_parquet('../output/country.parquet')
