# Mistplay Data Engineer Take Home Challenge

### Author: Henry Jia

Project structure:
- data: contains the input data file (data.json)
- output: contains the data files generated from the program
- src: contains the python scripts for this challenge
  - util: put the scripts holding the functions might be called frequently
    - HelperFunctions.py: contains helper functions for required functionality
  - DataProcessor.py: the entry point of this program 
- requirements.txt: list the libraries and their version needed to run this program

Guide:
1. make sure all the libraries needed are installed. 
   - if any library is missing, use pip install <library_name> to install
2. change current directory to the src folder in terminal
3. run python DataProcessor.py to execute the program in terminal